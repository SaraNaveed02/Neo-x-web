/**
 * SEO — dynamic canonical URL (works on localhost, LAN & Netlify)
 */
(function () {
    if (document.querySelector('link[rel="canonical"]')) {
        const canon = document.querySelector('link[rel="canonical"]');
        if (!canon.getAttribute('href') || canon.getAttribute('href') === './' || canon.getAttribute('href').startsWith('./')) {
            canon.setAttribute('href', window.location.href.split('#')[0].split('?')[0]);
        }
        return;
    }
    const link = document.createElement('link');
    link.rel = 'canonical';
    link.href = window.location.href.split('#')[0].split('?')[0];
    document.head.appendChild(link);
})();
