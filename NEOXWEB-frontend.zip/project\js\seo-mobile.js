/**
 * SEO + mobile meta — auto-inject on all pages via main.js
 */
(function () {
    const SITE_NAME = 'Nexura';

    function ensureMeta(name, content) {
        let el = document.querySelector(`meta[name="${name}"]`);
        if (!el) {
            el = document.createElement('meta');
            el.setAttribute('name', name);
            document.head.appendChild(el);
        }
        if (content) el.setAttribute('content', content);
    }

    ensureMeta('viewport', 'width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover');
    ensureMeta('theme-color', '#020617');
    ensureMeta('apple-mobile-web-app-capable', 'yes');
    ensureMeta('apple-mobile-web-app-status-bar-style', 'black-translucent');
    ensureMeta('mobile-web-app-capable', 'yes');
    ensureMeta('format-detection', 'telephone=yes');
    ensureMeta('robots', 'index, follow');

    if (!document.querySelector('link[rel="manifest"]')) {
        const m = document.createElement('link');
        m.rel = 'manifest';
        m.href = document.querySelector('script[src*="seo-mobile.js"]')
            ? document.querySelector('script[src*="seo-mobile.js"]').src.replace(/js\/seo-mobile\.js.*/, 'manifest.json')
            : 'manifest.json';
        document.head.appendChild(m);
    }

    if (!document.querySelector('link[rel="apple-touch-icon"]')) {
        const icon = document.createElement('link');
        icon.rel = 'apple-touch-icon';
        icon.href = 'assets/pwa/icon.svg';
        document.head.appendChild(icon);
    }

    const canonicalPath = window.location.pathname;
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
        canonical = document.createElement('link');
        canonical.rel = 'canonical';
        document.head.appendChild(canonical);
    }
    canonical.href = window.location.origin + canonicalPath;

    const title = document.title || SITE_NAME;
    const desc = document.querySelector('meta[name="description"]')?.getAttribute('content') || '';

    [['og:title', title], ['og:description', desc], ['og:type', 'website'], ['og:url', canonical.href]]
        .forEach(([prop, content]) => {
            if (!content) return;
            let el = document.querySelector(`meta[property="${prop}"]`);
            if (!el) {
                el = document.createElement('meta');
                el.setAttribute('property', prop);
                document.head.appendChild(el);
            }
            el.setAttribute('content', content);
        });

    if (desc && !document.querySelector('meta[name="twitter:card"]')) {
        ensureMeta('twitter:card', 'summary_large_image');
        ensureMeta('twitter:title', title);
        ensureMeta('twitter:description', desc);
    }
})();
