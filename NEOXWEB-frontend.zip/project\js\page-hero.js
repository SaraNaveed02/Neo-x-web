/**
 * Moving dots on inner-page heroes
 */
(function () {
    document.querySelectorAll('.nx-page-hero__particles').forEach((canvas) => {
        const hero = canvas.closest('.nx-page-hero, .cs-index-hero');
        if (!hero) return;

        const ctx = canvas.getContext('2d');
        const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        let particles = [];
        let w = 0;
        let h = 0;
        let raf = 0;

        function resize() {
            const rect = hero.getBoundingClientRect();
            w = Math.max(1, rect.width | 0);
            h = Math.max(1, rect.height | 0);
            canvas.width = w;
            canvas.height = h;
        }

        function seed() {
            const n = w < 600 ? 40 : 60;
            particles = Array.from({ length: n }, () => ({
                x: Math.random() * w,
                y: Math.random() * h,
                vx: (Math.random() - 0.5) * 0.5,
                vy: (Math.random() - 0.5) * 0.5,
                r: Math.random() * 1.5 + 0.8
            }));
        }

        function draw() {
            ctx.clearRect(0, 0, w, h);
            particles.forEach((p) => {
                p.x += p.vx;
                p.y += p.vy;
                if (p.x < 0 || p.x > w) p.vx *= -1;
                if (p.y < 0 || p.y > h) p.vy *= -1;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fillStyle = 'rgba(74, 222, 128, 0.75)';
                ctx.fill();
            });
            for (let i = 0; i < particles.length; i++) {
                for (let j = i + 1; j < particles.length; j++) {
                    const dx = particles[i].x - particles[j].x;
                    const dy = particles[i].y - particles[j].y;
                    const d = Math.hypot(dx, dy);
                    if (d < 110) {
                        ctx.strokeStyle = `rgba(34, 197, 94, ${(1 - d / 110) * 0.3})`;
                        ctx.lineWidth = 0.5;
                        ctx.beginPath();
                        ctx.moveTo(particles[i].x, particles[i].y);
                        ctx.lineTo(particles[j].x, particles[j].y);
                        ctx.stroke();
                    }
                }
            }
            raf = requestAnimationFrame(draw);
        }

        function start() {
            cancelAnimationFrame(raf);
            resize();
            seed();
            if (reduced) return;
            draw();
        }

        start();
        window.addEventListener('resize', () => setTimeout(start, 150));
    });
})();
