/**
 * NEOXWEB — local image fail hone par CDN + SVG fallback
 */
(function () {
    var CDN = 'https://neoxweb.pages.dev/static/images/';

    function siteBase() {
        if (window.__NEOXWEB_BASE__) return window.__NEOXWEB_BASE__;
        var path = location.pathname || '/';
        var slash = path.lastIndexOf('/');
        return slash >= 0 ? path.slice(0, slash + 1) : '/';
    }

    function attach(img) {
        if (!img || img.dataset.nxImgFix === '1') return;
        img.dataset.nxImgFix = '1';

        img.addEventListener('error', function onLocalFail() {
            img.removeEventListener('error', onLocalFail);
            var src = img.getAttribute('src') || '';
            var name = src.split('/').pop().split('?')[0];
            if (!name) return;

            if (/\.jpe?g$/i.test(name)) {
                img.src = CDN + name;
                img.addEventListener('error', function onCdnFail() {
                    img.removeEventListener('error', onCdnFail);
                    img.src = siteBase() + 'assets/images/neoxweb/' + name.replace(/\.jpe?g$/i, '.svg');
                }, { once: true });
                return;
            }

            if (/\.png$/i.test(name)) {
                img.src = CDN + name;
            }
        }, { once: true });
    }

    function scan(root) {
        (root || document).querySelectorAll('img[src]').forEach(attach);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () { scan(document); });
    } else {
        scan(document);
    }

    if (typeof MutationObserver !== 'undefined') {
        new MutationObserver(function (mutations) {
            mutations.forEach(function (m) {
                m.addedNodes.forEach(function (node) {
                    if (node.nodeType !== 1) return;
                    if (node.tagName === 'IMG') attach(node);
                    else scan(node);
                });
            });
        }).observe(document.documentElement, { childList: true, subtree: true });
    }
})();
