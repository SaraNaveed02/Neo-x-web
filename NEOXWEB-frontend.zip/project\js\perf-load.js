/** Async CSS — non-blocking (PageSpeed) */
window.NxLoadCSS = function (href) {
    var l = document.createElement('link');
    l.rel = 'stylesheet';
    l.href = href;
    document.head.appendChild(l);
};

window.NxDefer = function (fn) {
    if ('requestIdleCallback' in window) {
        requestIdleCallback(fn, { timeout: 2500 });
    } else {
        setTimeout(fn, 1);
    }
};
