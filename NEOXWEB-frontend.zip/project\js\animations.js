/*
    FILE: animations.js
    PURPOSE: Reveal animations for fade-up and glow elements
*/

document.addEventListener('DOMContentLoaded', () => {
    requestAnimationFrame(() => {
        qsa('.fade-up').forEach(item => item.classList.add('revealed'));
    });
});
