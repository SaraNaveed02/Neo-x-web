/**
 * Hero background — moving green dots + network lines (tech hero)
 */
(function () {
    const canvas = document.querySelector('.hero-particles-canvas, #heroParticles');
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const hero = canvas.closest('.hero-section--neoxweb, .hero-section--pro, .hero-section--cinematic, .hero-section');
    if (!hero) return;

    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let particles = [];
    let rafId = 0;
    let width = 0;
    let height = 0;

    function particleCount() {
        if (window.innerWidth < 900) return 0;
        if (window.innerWidth < 480) return 52;
        return 84;
    }

    function connectDistance() {
        return window.innerWidth < 600 ? 105 : 135;
    }

    function resize() {
        const rect = hero.getBoundingClientRect();
        width = Math.max(1, Math.floor(rect.width));
        height = Math.max(1, Math.floor(rect.height));
        canvas.width = width;
        canvas.height = height;
        canvas.style.width = width + 'px';
        canvas.style.height = height + 'px';
    }

    function createParticle() {
        const square = Math.random() < 0.14;
        const speed = square ? 1.35 : 1.85;
        return {
            x: Math.random() * width,
            y: Math.random() * height,
            vx: (Math.random() - 0.5) * speed,
            vy: (Math.random() - 0.5) * speed,
            r: square ? 0 : Math.random() * 1.6 + 0.9,
            size: square ? Math.random() * 2.5 + 1.5 : 0,
            square,
            alpha: 0.48 + Math.random() * 0.32
        };
    }

    function seedParticles() {
        particles = Array.from({ length: particleCount() }, createParticle);
    }

    function drawParticle(p) {
        if (p.square) {
            ctx.fillStyle = `rgba(52, 211, 153, ${p.alpha * 0.85})`;
            ctx.fillRect(p.x, p.y, p.size, p.size);
            return;
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        const glow = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.r * 3.2);
        glow.addColorStop(0, `rgba(167, 243, 208, ${Math.min(1, p.alpha + 0.15)})`);
        glow.addColorStop(0.45, `rgba(34, 197, 94, ${p.alpha * 0.55})`);
        glow.addColorStop(1, 'rgba(16, 185, 129, 0)');
        ctx.fillStyle = glow;
        ctx.fill();
    }

    function drawStatic() {
        resize();
        ctx.clearRect(0, 0, width, height);
        particles.forEach(drawParticle);
    }

    function step() {
        ctx.clearRect(0, 0, width, height);
        const maxDist = connectDistance();

        particles.forEach((p) => {
            p.x += p.vx;
            p.y += p.vy;
            if (p.x <= 0 || p.x >= width) p.vx *= -1;
            if (p.y <= 0 || p.y >= height) p.vy *= -1;
            drawParticle(p);
        });

        for (let i = 0; i < particles.length; i += 1) {
            for (let j = i + 1; j < particles.length; j += 1) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const dist = Math.hypot(dx, dy);
                if (dist < maxDist) {
                    const alpha = (1 - dist / maxDist) * 0.44;
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.strokeStyle = `rgba(52, 211, 153, ${alpha})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }

        rafId = requestAnimationFrame(step);
    }

    function start() {
        if (particleCount() === 0) return;
        cancelAnimationFrame(rafId);
        resize();
        seedParticles();
        if (prefersReduced) {
            drawStatic();
            return;
        }
        step();
    }

    let resizeTimer;
    window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(start, 150);
    });

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start);
    } else {
        start();
    }
})();
