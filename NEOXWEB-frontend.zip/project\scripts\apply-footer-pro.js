const fs = require('fs');
const path = require('path');

const root = path.join(__dirname, '..');

const footerHtml = `<footer class="site-footer site-footer--pro" role="contentinfo">
    <div class="container footer-pro__main">
        <div class="footer-pro__brand">
            <a href="index.html" class="footer-logo" aria-label="NEOXWEB Home">
                <img src="assets/images/neoxweb/logo-unified-full.svg" alt="NEOXWEB — Web Development &amp; Digital Marketing Pakistan" class="footer-logo-img" width="140" height="42" loading="lazy">
            </a>
            <p class="footer-pro__tagline">Your trusted partner for web development, SEO, PPC, social media, graphic design &amp; video editing in Pakistan.</p>
            <div class="footer-pro__social">
                <a href="https://wa.me/923140666734" target="_blank" rel="noopener noreferrer" aria-label="WhatsApp NEOXWEB"><i class="fab fa-whatsapp" aria-hidden="true"></i></a>
                <a href="mailto:supportneoxweb@gmail.com" aria-label="Email NEOXWEB"><i class="fas fa-envelope" aria-hidden="true"></i></a>
            </div>
        </div>
        <nav class="footer-pro__col" aria-label="Quick links">
            <h4>Quick Links</h4>
            <a href="index.html">Home</a>
            <a href="about.html">About Us</a>
            <a href="services.html">Services</a>
            <a href="portfolio.html">Portfolio</a>
            <a href="team.html">Our Team</a>
            <a href="contact.html">Contact</a>
        </nav>
        <nav class="footer-pro__col" aria-label="Our services">
            <h4>Our Services</h4>
            <a href="web.html">Web Development</a>
            <a href="data-analytics.html">SEO Optimization</a>
            <a href="ecommerce-strategy.html">PPC Advertising</a>
            <a href="product-design.html">Social Media Marketing</a>
            <a href="product-design.html">Graphic Design</a>
            <a href="contact.html">Video Editing</a>
        </nav>
        <div class="footer-pro__col footer-pro__contact">
            <h4>Contact Info</h4>
            <p><a href="mailto:supportneoxweb@gmail.com">supportneoxweb@gmail.com</a></p>
            <p><a href="https://wa.me/923140666734" target="_blank" rel="noopener">+92 314 066 6734</a></p>
            <p>Lahore · Karachi · Islamabad · Pakistan</p>
        </div>
    </div>
    <div class="footer-pro__bottom container">
        <p>&copy; 2026 NEOXWEB. All rights reserved.</p>
        <p class="footer-pro__seo-text">Web Development · SEO · Digital Marketing · Graphic Design · Video Editing · Lahore · Karachi · Islamabad · Pakistan</p>
    </div>
</footer>`;

const footerRe = /<footer class="site-footer[^"]*">[\s\S]*?<\/footer>/;

function addFooterCss(html) {
    if (html.includes('footer-pro.css')) return html;
    return html.replace(
        /(<link rel="stylesheet" href="css\/neoxweb-theme\.css">)/,
        '$1\n    <link rel="stylesheet" href="css/footer-pro.css">'
    );
}

const skip = new Set(['navbar.html', 'unified-header.html', 'unified-footer.html', 'oauth-callback.html']);

fs.readdirSync(root)
    .filter((f) => f.endsWith('.html') && !skip.has(f))
    .forEach((file) => {
        const full = path.join(root, file);
        let html = fs.readFileSync(full, 'utf8');
        if (!footerRe.test(html)) return;
        html = html.replace(footerRe, footerHtml);
        html = addFooterCss(html);
        fs.writeFileSync(full, html);
        console.log('footer', file);
    });

console.log('Done.');
