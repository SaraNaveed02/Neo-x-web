const fs = require('fs');
const path = require('path');
const https = require('https');

const outDir = path.join(__dirname, '..', 'assets', 'images', 'neoxweb');
const base = 'https://neoxweb.pages.dev/static/images/';

const files = [
    'web-dev.jpg',
    'seo-new.jpg',
    'ppc.jpg',
    'social-media-new.jpg',
    'portfolio-branding.jpg',
    'portfolio-web.jpg',
    'portfolio-seo.jpg',
    'portfolio-ppc.jpg',
    'hero-bg-new.jpg',
    'hero-tech-bg.png',
    'logo.png',
    'logo-large.jpg'
];

if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });

function download(name) {
    return new Promise((resolve) => {
        const dest = path.join(outDir, name);
        const file = fs.createWriteStream(dest);
        https.get(base + name, (res) => {
            if (res.statusCode === 301 || res.statusCode === 302) {
                file.close();
                fs.unlinkSync(dest);
                https.get(res.headers.location, (r2) => {
                    const f2 = fs.createWriteStream(dest);
                    r2.pipe(f2);
                    f2.on('finish', () => { f2.close(); resolve(name); });
                }).on('error', () => resolve(null));
                return;
            }
            if (res.statusCode !== 200) {
                file.close();
                fs.unlink(dest, () => {});
                console.warn('FAIL', name, res.statusCode);
                resolve(null);
                return;
            }
            res.pipe(file);
            file.on('finish', () => { file.close(); console.log('OK', name); resolve(name); });
        }).on('error', (e) => {
            file.close();
            console.warn('ERR', name, e.message);
            resolve(null);
        });
    });
}

(async () => {
    for (const f of files) await download(f);
    console.log('Done');
})();
