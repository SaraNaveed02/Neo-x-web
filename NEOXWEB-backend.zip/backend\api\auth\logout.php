<?php
/*
    FILE: api/auth/logout.php
    PURPOSE: Destroy the current session and logout user
*/

require_once '../../config/cors.php';
require_once '../../includes/response.php';

session_start();
session_destroy();

sendSuccess('Logged out successfully');
?>