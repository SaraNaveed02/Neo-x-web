<?php
/**
 * CSRF token for admin session (used by forms & mutating API calls)
 */
require_once __DIR__ . '/../../includes/bootstrap.php';
require_once __DIR__ . '/../../includes/request.php';
require_once __DIR__ . '/../../includes/security.php';
require_once __DIR__ . '/../../includes/response.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

requireMethod('GET');
sendSuccess(['token' => generateCSRFToken()]);
