<?php
/*
    FILE: api/auth/login.php
    PURPOSE: JWT login with login history tracking
*/

require_once '../../config/constants.php';
require_once '../../includes/functions.php';
require_once '../../includes/request.php';
require_once '../../includes/auth-jwt.php';
require_once '../../includes/activity.php';
require_once '../../includes/bootstrap.php';

requireMethod('POST');

$data = getJsonInput();
$email = sanitizeInput($data['email'] ?? '');
$password = $data['password'] ?? '';

if ($email === '' || $password === '') {
    sendError('Email and password are required');
}
if (!validateEmail($email)) {
    sendError('Invalid email format');
}

$db = db();

$stmt = $db->prepare('SELECT id, name, email, password, role, is_active FROM users WHERE email = ?');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || empty($user['password']) || !password_verify($password, $user['password'])) {
    sendError('Invalid email or password', 401);
}
if ((int) $user['is_active'] !== 1) {
    sendError('Account is inactive', 403);
}

setUserSession($user);
$loginType = $user['role'] === 'admin' ? 'admin' : 'client';
logLoginHistory($db, (int) $user['id'], $email, $loginType);
logActivity($db, 'login', $user['name'] . ' logged in', $email, (int) $user['id']);

$stats = syncDashboardStats($db);
emitRealtimeEvent('user:login', ['stats' => $stats, 'user' => ['name' => $user['name'], 'email' => $email]]);
emitRealtimeEvent('stats:update', $stats);

sendSuccess('Login successful', buildAuthResponse($db, $user));

?>
