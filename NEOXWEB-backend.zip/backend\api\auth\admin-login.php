<?php
/*
    FILE: api/auth/admin-login.php
    PURPOSE: Admin JWT login with session + login history
*/

require_once '../../config/constants.php';
require_once '../../includes/functions.php';
require_once '../../includes/request.php';
require_once '../../includes/auth-jwt.php';
require_once '../../includes/activity.php';
require_once '../../includes/security.php';
require_once '../../includes/bootstrap.php';

requireMethod('POST');

$data = getJsonInput();
$login = sanitizeInput($data['username'] ?? $data['email'] ?? '');
$password = $data['password'] ?? '';

if ($login === '' || $password === '') {
    sendError('Username and password are required', 400);
}

$db = db();

$stmt = $db->prepare(
    "SELECT id, name, email, password, role FROM users
     WHERE role = 'admin' AND (username = ? OR email = ? OR name = ?)
     LIMIT 1"
);
$stmt->execute([$login, $login, $login]);
$admin = $stmt->fetch();

if (!$admin || empty($admin['password']) || !password_verify($password, $admin['password'])) {
    sendError('Invalid admin credentials', 401);
}

setUserSession($admin);
logLoginHistory($db, (int) $admin['id'], $admin['email'], 'admin');
logActivity($db, 'login', 'Admin ' . $admin['name'] . ' logged in', $admin['email'], (int) $admin['id']);

$stats = syncDashboardStats($db);
emitRealtimeEvent('user:login', ['stats' => $stats, 'user' => ['name' => $admin['name'], 'role' => 'admin']]);
emitRealtimeEvent('stats:update', $stats);

$response = buildAuthResponse($db, $admin);
$response['csrf_token'] = generateCSRFToken();
sendSuccess('Admin login successful', $response);

?>
