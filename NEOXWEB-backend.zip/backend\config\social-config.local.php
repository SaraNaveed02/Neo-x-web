<?php
/*
    FILE: config/social-config.local.php
    Apni OAuth keys yahan paste karein (ye file sirf aapke PC par hai)

    Meta (Facebook + Instagram): https://developers.facebook.com/apps/
    GitHub: https://github.com/settings/developers
    Google: https://console.cloud.google.com/apis/credentials
*/

// ── Facebook Login (Meta App ID) ──
define('FACEBOOK_APP_ID', '');
define('FACEBOOK_APP_SECRET', '');

// ── Instagram (aksar same Meta App ID — Instagram Basic Display enable karein) ──
define('INSTAGRAM_APP_ID', '');
define('INSTAGRAM_APP_SECRET', '');

// ── GitHub OAuth App ──
define('GITHUB_CLIENT_ID', '');
define('GITHUB_CLIENT_SECRET', '');

// Redirect URI (Meta/GitHub console mein bhi ye add karein)
define('SOCIAL_REDIRECT_URI', 'http://localhost/time/project/oauth-callback.html');

?>
