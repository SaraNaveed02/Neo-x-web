<?php
/*
    FILE: api/health.php
    PURPOSE: Check API + database status
*/

require_once '../config/cors.php';
require_once '../config/database.php';
require_once '../includes/response.php';

$checks = [
    'api' => true,
    'database' => false,
    'tables' => [],
    'admin_user' => false
];

$database = new Database();
$db = $database->getConnection();

if ($db) {
    $checks['database'] = true;
    $tables = ['users', 'messages', 'login_history', 'activity_log', 'dashboard_stats', 'settings', 'services', 'site_stats'];
    foreach ($tables as $table) {
        try {
            $db->query("SELECT 1 FROM $table LIMIT 1");
            $checks['tables'][$table] = true;
        } catch (PDOException $e) {
            $checks['tables'][$table] = false;
        }
    }
    try {
        $stmt = $db->prepare("SELECT id FROM users WHERE username = 'admin' AND role = 'admin' LIMIT 1");
        $stmt->execute();
        $checks['admin_user'] = (bool) $stmt->fetch();
    } catch (PDOException $e) {
        $checks['admin_user'] = false;
    }
}

$allOk = $checks['database'] && $checks['admin_user'] && !in_array(false, $checks['tables'], true);

sendSuccess($allOk ? 'All systems OK' : 'Setup required — run install.php', [
    'checks' => $checks,
    'install_url' => '/time/backend/install.php',
    'admin_login' => ['username' => 'admin']
]);

?>
