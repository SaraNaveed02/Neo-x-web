/*
    FILE: abc.sql
    PURPOSE: Nexura Social Login Database
             Google + Facebook + Instagram + GitHub + Email
    IMPORT: phpMyAdmin → Import → abc.sql
            OR: http://localhost/phpmyadmin
    DATABASE: nexura_db
*/

CREATE DATABASE IF NOT EXISTS nexura_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE nexura_db;

-- ═══════════════════════════════════════════════════════════
-- USERS (Google, Facebook, Instagram, GitHub, Email signup)
-- ═══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NULL COMMENT 'NULL for social-only accounts',
    avatar_url VARCHAR(500) NULL COMMENT 'Profile photo from Google/Facebook',

    -- Social provider IDs (unique per platform)
    google_id VARCHAR(255) NULL UNIQUE COMMENT 'Google OAuth sub/id',
    facebook_id VARCHAR(255) NULL UNIQUE COMMENT 'Facebook Graph user id',
    instagram_id VARCHAR(255) NULL UNIQUE COMMENT 'Instagram Basic Display id',
    github_id VARCHAR(255) NULL UNIQUE COMMENT 'GitHub user id',
    linkedin_id VARCHAR(255) NULL UNIQUE COMMENT 'Optional LinkedIn id',

    auth_provider ENUM('email', 'google', 'facebook', 'instagram', 'github', 'linkedin') DEFAULT 'email'
        COMMENT 'Last login / primary signup method',

    role ENUM('admin', 'client') NOT NULL DEFAULT 'client',
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    email_verified TINYINT(1) NOT NULL DEFAULT 0,
    last_login_at TIMESTAMP NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_users_email (email),
    INDEX idx_users_google (google_id),
    INDEX idx_users_facebook (facebook_id),
    INDEX idx_users_instagram (instagram_id),
    INDEX idx_users_github (github_id),
    INDEX idx_users_provider (auth_provider),
    INDEX idx_users_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ═══════════════════════════════════════════════════════════
-- LOGIN HISTORY (har login track — Google/Facebook/Instagram)
-- ═══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS login_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    email VARCHAR(100) NOT NULL,
    login_provider ENUM('email', 'google', 'facebook', 'instagram', 'github', 'linkedin', 'admin') DEFAULT 'email',
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    login_type ENUM('client', 'admin') NOT NULL DEFAULT 'client',
    status ENUM('success', 'failed') NOT NULL DEFAULT 'success',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_login_user (user_id),
    INDEX idx_login_email (email),
    INDEX idx_login_provider (login_provider),
    INDEX idx_login_created (created_at),

    CONSTRAINT fk_login_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ═══════════════════════════════════════════════════════════
-- ACTIVITY LOG (signup / login events)
-- ═══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS activity_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    activity_type ENUM('signup', 'login', 'message', 'oauth_link', 'oauth_unlink') NOT NULL,
    user_id INT NULL,
    reference_id INT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NULL,
    meta JSON NULL COMMENT 'Extra data: provider, ip, etc.',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_activity_type (activity_type),
    INDEX idx_activity_user (user_id),
    INDEX idx_activity_created (created_at),

    CONSTRAINT fk_activity_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ═══════════════════════════════════════════════════════════
-- OAUTH SETTINGS (Client IDs — database se manage)
-- ═══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT NULL,
    setting_group VARCHAR(50) NOT NULL DEFAULT 'general',
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    INDEX idx_settings_group (setting_group)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ═══════════════════════════════════════════════════════════
-- DASHBOARD STATS
-- ═══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS dashboard_stats (
    stat_key VARCHAR(50) PRIMARY KEY,
    stat_value BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ═══════════════════════════════════════════════════════════
-- SOCIAL LOGIN AUDIT (optional detailed log per OAuth attempt)
-- ═══════════════════════════════════════════════════════════
CREATE TABLE IF NOT EXISTS social_login_log (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    provider ENUM('google', 'facebook', 'instagram', 'github', 'linkedin') NOT NULL,
    provider_user_id VARCHAR(255) NULL,
    email VARCHAR(100) NULL,
    action ENUM('signup', 'login', 'failed') NOT NULL DEFAULT 'login',
    ip_address VARCHAR(45) NULL,
    user_agent VARCHAR(255) NULL,
    error_message VARCHAR(255) NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_social_user (user_id),
    INDEX idx_social_provider (provider),
    INDEX idx_social_created (created_at),

    CONSTRAINT fk_social_user
        FOREIGN KEY (user_id) REFERENCES users(id)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ═══════════════════════════════════════════════════════════
-- DEFAULT ADMIN USER
-- Login: admin@example.com  |  Password: admin123
-- ═══════════════════════════════════════════════════════════
INSERT INTO users (username, name, email, password, role, auth_provider, is_active)
VALUES (
    'admin',
    'Admin User',
    'admin@example.com',
    '$2y$10$j.UiuQW5Clh66L/pEg35b.nnlEB004LvobhhzIr4ZozF.35NRBpbK',
    'admin',
    'email',
    1
)
ON DUPLICATE KEY UPDATE
    name = VALUES(name),
    role = VALUES(role),
    is_active = VALUES(is_active);

-- ═══════════════════════════════════════════════════════════
-- OAUTH CLIENT IDs (Google / Facebook / Instagram / GitHub)
-- Admin panel → Settings se bhi edit ho sakte hain
-- ═══════════════════════════════════════════════════════════
INSERT INTO settings (setting_key, setting_value, setting_group) VALUES
('google_client_id', '99201620546-16nvbeh9uspnr8117m1ijeqj5up3e4kg.apps.googleusercontent.com', 'oauth'),
('google_client_secret', '', 'oauth'),
('facebook_app_id', '', 'oauth'),
('facebook_app_secret', '', 'oauth'),
('instagram_app_id', '', 'oauth'),
('instagram_app_secret', '', 'oauth'),
('github_client_id', '', 'oauth'),
('github_client_secret', '', 'oauth'),
('oauth_redirect_uri', 'http://localhost/time/project/oauth-callback.html', 'oauth'),
('site_name', 'Nexura', 'general'),
('site_tagline', 'Premium Software Agency', 'general'),
('contact_email', 'hello@nexura-agency.com', 'contact'),
('maintenance_mode', '0', 'system')
ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value);

-- ═══════════════════════════════════════════════════════════
-- DASHBOARD COUNTERS
-- ═══════════════════════════════════════════════════════════
INSERT INTO dashboard_stats (stat_key, stat_value) VALUES
('total_users', 0),
('total_messages', 0),
('total_logins', 0),
('google_logins', 0),
('facebook_logins', 0),
('instagram_logins', 0),
('github_logins', 0)
ON DUPLICATE KEY UPDATE stat_key = VALUES(stat_key);

-- ═══════════════════════════════════════════════════════════
-- FRESH INSTALL: pehle DROP DATABASE uncomment karein, phir import
-- DROP DATABASE IF EXISTS nexura_db;
--
-- EXISTING DB UPGRADE: http://localhost/time/backend/database/setup.php
-- ═══════════════════════════════════════════════════════════
