﻿<?php
$pageTitle = 'Dashboard';
$activeNav = 'dashboard';
include 'includes/layout-start.php';
echo ui_partial_meta($pageTitle, $activeNav);
?>

<div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 lg:gap-6 mb-8">
    <?php
    echo ui_stat_card('statUsers', 'Total Users', 'fa-users', 'violet');
    echo ui_stat_card('statMessages', 'Total Messages', 'fa-envelope', 'emerald');
    echo ui_stat_card('statLogins', 'Total Logins', 'fa-right-to-bracket', 'cyan');
    echo ui_stat_card('statMonth', 'New This Month', 'fa-calendar', 'amber');
    ?>
</div>

<div class="grid grid-cols-1 xl:grid-cols-2 gap-6">
    <section class="nx-card overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
            <h2 class="font-semibold"><i class="fas fa-bolt text-violet-400 mr-2"></i>Recent Activity</h2>
        </div>
        <div id="activityList" class="divide-y divide-slate-800 max-h-96 overflow-y-auto">
            <p class="p-6 text-slate-500 text-sm">Loading activity...</p>
        </div>
    </section>

    <section class="nx-card overflow-hidden">
        <div class="px-6 py-4 border-b border-slate-800 flex items-center justify-between">
            <h2 class="font-semibold"><i class="fas fa-inbox text-emerald-400 mr-2"></i>Recent Messages</h2>
            <a href="messages.php" data-spa-link class="text-sm text-violet-400 hover:text-violet-300">View all</a>
        </div>
        <div id="messageList" class="divide-y divide-slate-800 max-h-96 overflow-y-auto">
            <p class="p-6 text-slate-500 text-sm">Loading messages...</p>
        </div>
    </section>
</div>

<?php
$pageScript = <<<'SCRIPT'
<script>
function activityIcon(type) {
    if (type === 'signup') return 'fa-user-plus text-emerald-400';
    if (type === 'login') return 'fa-right-to-bracket text-cyan-400';
    return 'fa-envelope text-violet-400';
}

function renderActivity(items) {
    const el = document.getElementById('activityList');
    if (!items.length) {
        el.innerHTML = '<p class="p-6 text-slate-500 text-sm">No activity yet</p>';
        return;
    }
    el.innerHTML = items.map(a => `
        <div class="px-6 py-4 flex gap-3 items-start">
            <div class="w-9 h-9 rounded-lg bg-slate-800 flex items-center justify-center shrink-0"><i class="fas ${activityIcon(a.activity_type)}"></i></div>
            <div class="min-w-0 flex-1">
                <p class="font-medium text-sm">${escapeHtml(a.title)}</p>
                <p class="text-slate-400 text-xs truncate">${escapeHtml(a.description || '')}</p>
                <p class="text-slate-500 text-xs mt-1">${new Date(a.created_at).toLocaleString()}</p>
            </div>
            <button onclick="deleteActivity(${a.id})" class="text-red-400 hover:text-red-300 shrink-0 p-1" title="Delete"><i class="fas fa-trash text-xs"></i></button>
        </div>
    `).join('');
}

function renderMessages(msgs) {
    const el = document.getElementById('messageList');
    if (!msgs.length) {
        el.innerHTML = '<p class="p-6 text-slate-500 text-sm">No messages yet</p>';
        return;
    }
    el.innerHTML = msgs.map(m => `
        <div class="px-6 py-4 flex gap-3 items-start">
            <div class="flex-1 min-w-0">
                <div class="flex justify-between gap-2 mb-1">
                    <p class="font-medium text-sm">${escapeHtml(m.name)}</p>
                    <span class="text-xs text-slate-500">${new Date(m.created_at).toLocaleString()}</span>
                </div>
                <p class="text-slate-400 text-xs">${escapeHtml(m.email)}</p>
                <p class="text-slate-300 text-sm mt-2 line-clamp-2">${escapeHtml(m.message)}</p>
            </div>
            <button onclick="deleteDashboardMessage(${m.id})" class="text-red-400 hover:text-red-300 shrink-0 p-1" title="Delete"><i class="fas fa-trash text-xs"></i></button>
        </div>
    `).join('');
}

function applyStats(stats) {
    document.getElementById('statUsers').textContent = stats.total_users ?? 0;
    document.getElementById('statMessages').textContent = stats.total_messages ?? 0;
    document.getElementById('statLogins').textContent = stats.total_logins ?? 0;
}

async function loadDashboard() {
    try {
        const res = await AdminAPI.get('dashboard/stats.php');
        const d = res.data;
        applyStats(d);
        document.getElementById('statMonth').textContent = d.new_this_month ?? 0;
        renderActivity(d.recent_activity || []);
        renderMessages(d.recent_messages || []);
    } catch (err) {
        showToast(err.message, 'error');
    }
}

async function deleteActivity(id) {
    if (!confirm('Delete this activity?')) return;
    try {
        await AdminAPI.delete('activity/delete.php', { id });
        showToast('Activity deleted');
        loadDashboard();
    } catch (err) { showToast(err.message, 'error'); }
}

async function deleteDashboardMessage(id) {
    if (!confirm('Delete this message?')) return;
    try {
        await AdminAPI.delete('messages/delete.php', { id });
        showToast('Message deleted');
        loadDashboard();
    } catch (err) { showToast(err.message, 'error'); }
}

initRealtime({
    onStats: (stats) => { applyStats(stats); loadDashboard(); },
    onMessage: () => { showToast('New message received'); loadDashboard(); },
    onSignup: () => { showToast('New user registered'); loadDashboard(); },
    onLogin: () => loadDashboard()
});

loadDashboard();
</script>
SCRIPT;

include 'includes/layout-end.php';
?>
