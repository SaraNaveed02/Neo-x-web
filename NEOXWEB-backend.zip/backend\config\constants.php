<?php
/*
    FILE: config/constants.php
    PURPOSE: Application constants
*/

define('BASE_PATH', dirname(__DIR__));
define('ADMIN_PATH', BASE_PATH . '/admin');
define('API_PATH', BASE_PATH . '/api');
define('UPLOAD_PATH', BASE_PATH . '/uploads');

define('BASE_URL', 'http://localhost/time/backend');
define('API_URL', BASE_URL . '/api');
define('FRONTEND_URL', 'http://localhost/time/project');

define('APP_NAME', 'Nexura Admin');
define('APP_VERSION', '3.0.0');

define('JWT_SECRET', 'nexura-jwt-secret-change-in-production-2026');
define('JWT_TTL', 86400 * 7);

define('REALTIME_URL', 'http://localhost:3001');
define('REALTIME_SECRET', 'nexura-realtime-secret-key');

?>
