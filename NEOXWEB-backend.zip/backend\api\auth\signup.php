<?php
/*
    FILE: api/auth/signup.php
    PURPOSE: User registration with JWT + activity tracking
*/

require_once '../../config/constants.php';
require_once '../../includes/functions.php';
require_once '../../includes/request.php';
require_once '../../includes/auth-jwt.php';
require_once '../../includes/activity.php';
require_once '../../includes/bootstrap.php';

requireMethod('POST');

$data = getJsonInput();
$name = sanitizeInput($data['name'] ?? '');
$email = sanitizeInput($data['email'] ?? '');
$password = $data['password'] ?? '';

if ($name === '' || $email === '' || $password === '') {
    sendError('All fields are required');
}
if (!validateEmail($email)) {
    sendError('Invalid email format');
}
if (strlen($password) < 6) {
    sendError('Password must be at least 6 characters');
}

$db = db();

$check = $db->prepare('SELECT id FROM users WHERE email = ?');
$check->execute([$email]);
if ($check->fetch()) {
    sendError('Email already registered', 409);
}

$hash = password_hash($password, PASSWORD_DEFAULT);
$stmt = $db->prepare("INSERT INTO users (name, email, password, role, auth_provider) VALUES (?, ?, ?, 'client', 'email')");
$stmt->execute([$name, $email, $hash]);
$userId = (int) $db->lastInsertId();

$user = ['id' => $userId, 'name' => $name, 'email' => $email, 'role' => 'client'];
setUserSession($user);
logActivity($db, 'signup', $name . ' registered', $email, $userId, $userId);

$stats = syncDashboardStats($db);
emitRealtimeEvent('user:registered', ['stats' => $stats, 'user' => ['name' => $name, 'email' => $email]]);
emitRealtimeEvent('stats:update', $stats);

sendSuccess('Registration successful', buildAuthResponse($db, $user));

?>
