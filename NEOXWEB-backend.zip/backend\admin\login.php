<!DOCTYPE html>
<html lang="en" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <meta name="theme-color" content="#020617">
    <title>Admin Login | Nexura</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="assets/nexura-ui.css">
</head>
<body class="nx-app-body bg-slate-950 min-h-screen flex items-center justify-center p-4 font-sans">
    <div id="loginLoader" class="nx-page-loader hidden"><div class="nx-spinner"></div></div>

    <div class="w-full max-w-md rounded-2xl bg-slate-900 border border-slate-800 p-6 sm:p-8 shadow-2xl nx-animate-in">
        <div class="text-center mb-8">
            <div class="w-14 h-14 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-violet-600 to-emerald-500 grid place-items-center text-2xl">✦</div>
            <h1 class="text-2xl font-extrabold bg-gradient-to-r from-violet-500 to-emerald-400 bg-clip-text text-transparent">NEXURA APP</h1>
            <p class="text-slate-400 text-sm mt-2">Secure admin console</p>
        </div>
        <form id="loginForm" class="space-y-4" novalidate>
            <div>
                <label class="block text-sm text-slate-400 mb-1.5" for="username">Username</label>
                <input type="text" id="username" required placeholder="Username" autocomplete="username" class="nx-input">
            </div>
            <div>
                <label class="block text-sm text-slate-400 mb-1.5" for="password">Password</label>
                <input type="password" id="password" required placeholder="Password" autocomplete="current-password" class="nx-input">
            </div>
            <button type="submit" id="loginSubmitBtn" class="nx-btn nx-btn-primary w-full py-3.5">
                <span id="loginBtnText">Sign in to dashboard</span>
                <i id="loginBtnSpinner" class="fas fa-spinner fa-spin hidden"></i>
            </button>
            <p id="errorMsg" class="text-red-400 text-sm text-center hidden"></p>
        </form>
        <p class="text-center mt-6 space-y-2">
            <a href="../confirm.php" class="block text-emerald-400 text-sm hover:text-emerald-300">Backend health check</a>
            <a href="../../project/index.html" class="block text-violet-400 text-sm hover:text-violet-300">← Public website</a>
        </p>
    </div>

    <script src="assets/nexura-ui.js"></script>
    <script>
        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const err = document.getElementById('errorMsg');
            const loader = document.getElementById('loginLoader');
            const btnText = document.getElementById('loginBtnText');
            const spinner = document.getElementById('loginBtnSpinner');
            err.classList.add('hidden');
            loader.classList.remove('hidden');
            btnText.textContent = 'Signing in...';
            spinner.classList.remove('hidden');

            try {
                const res = await fetch('../api/auth/admin-login.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include',
                    body: JSON.stringify({
                        username: document.getElementById('username').value.trim(),
                        password: document.getElementById('password').value
                    })
                });
                const data = await res.json();
                if (data.success) {
                    if (data.data?.token) localStorage.setItem('nexuraAdminToken', data.data.token);
                    if (data.data?.csrf_token) localStorage.setItem('nexuraAdminCsrf', data.data.csrf_token);
                    window.location.href = 'dashboard.php';
                } else {
                    err.textContent = data.error || 'Login failed';
                    err.classList.remove('hidden');
                }
            } catch {
                err.textContent = 'Server connect nahi hua — XAMPP Apache + MySQL on karein';
                err.classList.remove('hidden');
            } finally {
                loader.classList.add('hidden');
                btnText.textContent = 'Sign in to dashboard';
                spinner.classList.add('hidden');
            }
        });
    </script>
</body>
</html>
