﻿<?php
$pageTitle = 'Users';
$activeNav = 'users';
include 'includes/layout-start.php';
echo ui_partial_meta($pageTitle, $activeNav);
?>

<?php echo ui_page_header('User Management', 'Clients and administrators'); ?>

<div class="flex flex-col sm:flex-row gap-3 justify-between mb-6">
    <?php echo ui_search_input('searchInput', 'Search users...'); ?>
    <?php echo ui_btn('Add User', 'openUserModal()', 'primary', 'fa-user-plus'); ?>
</div>

<?php echo ui_error_banner('loadError'); ?>

<?php
echo ui_modal_shell('userModal', 'Add User', '
    <form id="userForm" class="space-y-3">
        <input type="hidden" id="userId">
        <input id="userName" required placeholder="Full name" class="nx-input">
        <input id="userEmail" type="email" required placeholder="Email" class="nx-input">
        <input id="userPassword" type="password" placeholder="Password (min 6)" class="nx-input">
        <select id="userRole" class="nx-input">
            <option value="client">Client</option>
            <option value="admin">Admin</option>
        </select>
        <div class="flex justify-end gap-2 pt-2">
            <button type="button" class="nx-btn nx-btn-secondary" data-close-modal="userModal">Cancel</button>
            <button type="submit" class="nx-btn nx-btn-primary">Save</button>
        </div>
    </form>
');
?>

<?php
echo ui_table_wrap(
    '<tr>
        <th class="sortable" data-sort="name">Name</th>
        <th class="sortable" data-sort="email">Email</th>
        <th class="sortable" data-sort="role">Role</th>
        <th>Login</th>
        <th class="sortable" data-sort="created_at">Registered</th>
        <th>Actions</th>
    </tr>',
    'usersBody',
    '800px'
);
?>

<?php
$pageScript = <<<'SCRIPT'
<script>
let users = [];
let usersTable = null;

function renderLoginBadges(u) {
    const badges = [];
    if (u.google_id) badges.push('<i class="fab fa-google text-red-400" title="Google"></i>');
    if (u.facebook_id) badges.push('<i class="fab fa-facebook-f text-blue-400" title="Facebook"></i>');
    if (u.instagram_id) badges.push('<i class="fab fa-instagram text-pink-400" title="Instagram"></i>');
    if (u.github_id) badges.push('<i class="fab fa-github text-slate-200" title="GitHub"></i>');
    if (!badges.length) badges.push('<i class="fas fa-envelope text-slate-400" title="Email"></i>');
    const label = u.auth_provider ? u.auth_provider : (badges.length > 1 ? 'multi' : 'email');
    return badges.join(' ') + ` <span class="text-xs ml-1 capitalize">${escapeHtml(label)}</span>`;
}

function openUserModal() {
    document.getElementById('userModalTitle').textContent = 'Add User';
    document.getElementById('userForm').reset();
    document.getElementById('userId').value = '';
    NexuraUI.openModal('userModal');
}

async function loadUsers() {
    const errEl = document.getElementById('loadError');
    errEl.classList.add('hidden');
    try {
        const res = await AdminAPI.get('users/read.php');
        users = res.data || [];
        renderUsers(users);
    } catch (err) {
        errEl.textContent = err.message;
        errEl.classList.remove('hidden');
        showToast(err.message, 'error');
    }
}

function renderUsers(list) {
    if (!usersTable) {
        usersTable = NexuraUI.createDataTable({
            data: list,
            tbodyId: 'usersBody',
            paginationId: 'usersBodyPagination',
            searchInputId: 'searchInput',
            pageSize: 10,
            columns: [{ key: 'name' }, { key: 'email' }, { key: 'role' }],
            renderRow: (u) => `
                <tr class="hover:bg-slate-800/40">
                    <td class="font-medium">${escapeHtml(u.name)}</td>
                    <td class="text-slate-300">${escapeHtml(u.email)}</td>
                    <td><span class="px-2 py-1 rounded-full text-xs ${u.role === 'admin' ? 'bg-violet-500/20 text-violet-300' : 'bg-emerald-500/20 text-emerald-300'}">${u.role}</span></td>
                    <td class="text-slate-400">${renderLoginBadges(u)}</td>
                    <td class="text-slate-400">${new Date(u.created_at).toLocaleDateString()}</td>
                    <td>
                        <button onclick='editUser(${JSON.stringify(u)})' class="text-violet-400 mr-3"><i class="fas fa-edit"></i></button>
                        <button onclick="deleteUser(${u.id})" class="text-red-400"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>`
        });
    } else {
        usersTable.setData(list);
    }
}

function editUser(u) {
    openUserModal();
    document.getElementById('userModalTitle').textContent = 'Edit User';
    document.getElementById('userId').value = u.id;
    document.getElementById('userName').value = u.name;
    document.getElementById('userEmail').value = u.email;
    document.getElementById('userRole').value = u.role;
    document.getElementById('userPassword').value = '';
}

document.getElementById('userForm').addEventListener('submit', async e => {
    e.preventDefault();
    const id = document.getElementById('userId').value;
    const payload = {
        name: document.getElementById('userName').value.trim(),
        email: document.getElementById('userEmail').value.trim(),
        role: document.getElementById('userRole').value
    };
    const pw = document.getElementById('userPassword').value;
    if (pw) payload.password = pw;
    try {
        if (id) {
            payload.id = parseInt(id, 10);
            await AdminAPI.put('users/update.php', payload);
            showToast('User updated');
        } else {
            if (!pw || pw.length < 6) return showToast('Password min 6 chars', 'error');
            payload.password = pw;
            await AdminAPI.post('users/create.php', payload);
            showToast('User created');
        }
        NexuraUI.closeModal('userModal');
        loadUsers();
    } catch (err) { showToast(err.message, 'error'); }
});

async function deleteUser(id) {
    if (!confirm('Delete this user?')) return;
    try {
        await AdminAPI.delete('users/delete.php', { id });
        showToast('User deleted');
        loadUsers();
    } catch (err) { showToast(err.message, 'error'); }
}

initRealtime({ onSignup: () => { showToast('New user!'); loadUsers(); } });
loadUsers();
setInterval(loadUsers, 20000);
</script>
SCRIPT;

include 'includes/layout-end.php';
?>
