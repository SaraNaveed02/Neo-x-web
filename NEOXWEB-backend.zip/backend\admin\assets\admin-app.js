/**
 * Nexura Admin — API client, JWT, Socket.io realtime
 */

const AdminAPI = {
    base: '../api',
    csrfToken: '',

    getToken() {
        return localStorage.getItem('nexuraAdminToken') || '';
    },

    setToken(token) {
        if (token) localStorage.setItem('nexuraAdminToken', token);
        else localStorage.removeItem('nexuraAdminToken');
    },

    async request(endpoint, options = {}) {
        const headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            ...(options.headers || {})
        };
        const token = this.getToken();
        if (token) headers['Authorization'] = `Bearer ${token}`;
        if (this.csrfToken && ['POST', 'PUT', 'DELETE', 'PATCH'].includes((options.method || 'GET').toUpperCase())) {
            headers['X-CSRF-Token'] = this.csrfToken;
        }

        const config = { credentials: 'include', ...options, headers };
        if (config.body && typeof config.body === 'object') {
            config.body = JSON.stringify(config.body);
        }

        const res = await fetch(`${this.base}/${endpoint}`, config);
        const data = await res.json().catch(() => ({ success: false, error: 'Invalid response' }));
        if (!data.success) throw new Error(data.error || 'Request failed');
        return data;
    },

    get: (e) => AdminAPI.request(e, { method: 'GET' }),
    post: (e, b) => AdminAPI.request(e, { method: 'POST', body: b }),
    put: (e, b) => AdminAPI.request(e, { method: 'PUT', body: b }),
    delete: (e, b) => AdminAPI.request(e, { method: 'DELETE', body: b })
};

let realtimeSocket = null;

function initRealtime(callbacks = {}) {
    if (typeof io === 'undefined') return;
    realtimeSocket = io('http://localhost:3001', { transports: ['websocket', 'polling'] });

    realtimeSocket.on('connect', () => {
        const el = document.getElementById('liveIndicator');
        if (el) el.classList.remove('hidden');
    });

    realtimeSocket.on('stats:update', (stats) => callbacks.onStats?.(stats));
    realtimeSocket.on('message:new', (payload) => {
        callbacks.onMessage?.(payload);
        NexuraUI?.pushNotification('New message', payload?.name || 'Contact form');
    });
    realtimeSocket.on('user:registered', (payload) => {
        callbacks.onSignup?.(payload);
        NexuraUI?.pushNotification('New signup', payload?.email || '');
    });
    realtimeSocket.on('user:login', (payload) => {
        callbacks.onLogin?.(payload);
        NexuraUI?.pushNotification('User login', payload?.email || '');
    });
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
}

function escapeHtml(str) {
    if (!str) return '';
    return String(str).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

async function adminLogout() {
    try { await AdminAPI.post('auth/logout.php', {}); } catch (_) {}
    AdminAPI.setToken('');
    window.location.href = 'login.php';
}

window.AdminAPI = AdminAPI;
window.initRealtime = initRealtime;
window.toggleSidebar = toggleSidebar;
window.escapeHtml = escapeHtml;
window.adminLogout = adminLogout;
