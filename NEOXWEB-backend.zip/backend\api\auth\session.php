<?php
/*
    FILE: api/auth/session.php
    PURPOSE: Validate JWT or session and return current user profile
*/

require_once '../../config/cors.php';
require_once '../../config/constants.php';
require_once '../../includes/response.php';
require_once '../../includes/request.php';
require_once '../../includes/auth-jwt.php';
require_once '../../includes/bootstrap.php';
require_once '../../includes/oauth-user.php';

requireMethod('GET');

$user = authenticateRequest();
if (!$user) {
    sendError('Not authenticated', 401);
}

$db = db();
ensureOAuthUserColumns($db);

$stmt = $db->prepare('SELECT id, name, email, role, avatar_url, auth_provider, google_id, facebook_id, instagram_id, github_id, created_at, last_login_at FROM users WHERE id = ? LIMIT 1');
$stmt->execute([(int) $user['user_id']]);
$row = $stmt->fetch();

if (!$row) {
    sendError('User not found', 404);
}

$providers = [];
if (!empty($row['google_id'])) $providers[] = 'google';
if (!empty($row['facebook_id'])) $providers[] = 'facebook';
if (!empty($row['instagram_id'])) $providers[] = 'instagram';
if (!empty($row['github_id'])) $providers[] = 'github';
if (empty($providers)) {
    $providers[] = 'email';
}

sendSuccess('Session active', [
    'user_id' => (int) $row['id'],
    'name' => $row['name'],
    'email' => $row['email'],
    'role' => $row['role'],
    'avatar_url' => $row['avatar_url'] ?? '',
    'auth_provider' => $row['auth_provider'] ?? 'email',
    'providers' => $providers,
    'member_since' => $row['created_at'],
    'last_login_at' => $row['last_login_at'],
    'lastActive' => time(),
]);

?>
