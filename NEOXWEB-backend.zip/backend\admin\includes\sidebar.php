<?php
/** @deprecated Use layout-start.php sidebar — redirects to dashboard */
header('Location: dashboard.php', true, 302);
exit;
