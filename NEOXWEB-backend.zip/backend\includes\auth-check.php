<?php
/*
    FILE: includes/auth-check.php
    PURPOSE: Session authentication guards for API and admin
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && (int) $_SESSION['user_id'] > 0;
}

function getSessionUserId() {
    return isset($_SESSION['user_id']) ? (int) $_SESSION['user_id'] : 0;
}

function denyJson($message = 'Unauthorized', $statusCode = 401) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=UTF-8');
    echo json_encode(['success' => false, 'error' => $message]);
    exit;
}

function requireAdminRole() {
    require_once __DIR__ . '/auth-jwt.php';
    requireAdminAuth();
}

function requireLogin() {
    require_once __DIR__ . '/auth-jwt.php';
    requireAdminAuth();
}

function requireUserSession() {
    if (!isUserLoggedIn()) {
        denyJson('Authentication required', 401);
    }
}

function requireAdminPage() {
    if (!isAdminLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

?>
