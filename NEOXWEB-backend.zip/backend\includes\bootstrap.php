<?php
/*
    FILE: includes/bootstrap.php
    PURPOSE: Load CORS, database, return PDO or JSON error
*/

require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/response.php';

function db(): PDO
{
    static $connection = null;

    if ($connection instanceof PDO) {
        return $connection;
    }

    $database = new Database();
    $connection = $database->getConnection();

    if (!$connection) {
        sendError(
            'Database not connected. Open http://localhost/time/backend/install.php and click Install.',
            503
        );
    }

    return $connection;
}

?>
