<?php
/*
    FILE: admin/logout.php
    PURPOSE: Admin logout
*/
session_start();
session_destroy();
header('Location: login.php');
exit;
?>