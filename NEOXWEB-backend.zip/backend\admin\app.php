<?php
/**
 * Nexura Admin — single application entry (redirects to dashboard)
 */
header('Location: dashboard.php', true, 302);
exit;
