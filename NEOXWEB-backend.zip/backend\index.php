<?php
/*
    FILE: backend/index.php
    PURPOSE: Main entry point - redirects to admin panel
*/
session_start();

// Redirect to admin login if not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: admin/login.php');
    exit;
}

header('Location: admin/dashboard.php');
exit;
?>