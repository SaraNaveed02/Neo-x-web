<?php
/**
 * One-click database installer
 * Open: http://localhost/time/backend/install.php
 */
header('Content-Type: text/html; charset=UTF-8');

$message = '';
$success = false;
$mysqlOk = false;
$dbOk = false;
$userCount = 0;

function checkDatabaseStatus(): array
{
    $status = ['mysql' => false, 'database' => false, 'users' => 0, 'error' => ''];

    try {
        $pdo = new PDO('mysql:host=localhost;charset=utf8mb4', 'root', '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 3,
        ]);
        $status['mysql'] = true;

        $pdo->exec('USE nexura_db');
        $status['database'] = true;
        $status['users'] = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
    } catch (PDOException $e) {
        $status['error'] = $e->getMessage();
    }

    return $status;
}

$status = checkDatabaseStatus();
$mysqlOk = $status['mysql'];
$dbOk = $status['database'];
$userCount = $status['users'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$mysqlOk) {
        $message = 'MySQL nahi chal raha — XAMPP Control Panel → MySQL → <strong>Start</strong> karein, phir dubara try karein.';
    } else {
        try {
            $pdo = new PDO('mysql:host=localhost;charset=utf8mb4', 'root', '', [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
            ]);

            $sql = file_get_contents(__DIR__ . '/database/db.sql');
            $statements = preg_split('/;\s*\n/', $sql);

            foreach ($statements as $statement) {
                $statement = trim($statement);
                if ($statement === '' || strpos($statement, '--') === 0) {
                    continue;
                }
                try {
                    $pdo->exec($statement);
                } catch (PDOException $e) {
                    // ignore duplicate etc.
                }
            }

            require_once __DIR__ . '/includes/site-stats.php';
            $pdo->exec('USE nexura_db');
            seedDefaultSiteStats($pdo);

            $success = true;
            $message = 'Database installed! Admin: username <strong>admin</strong> password <strong>admin123</strong>';
            $status = checkDatabaseStatus();
            $dbOk = $status['database'];
            $userCount = $status['users'];
        } catch (PDOException $e) {
            $message = 'Error: ' . htmlspecialchars($e->getMessage());
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install Database | Nexura</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-950 text-white min-h-screen flex items-center justify-center p-4">
    <div class="max-w-md w-full bg-slate-900 border border-slate-800 rounded-2xl p-8 text-center">
        <h1 class="text-2xl font-bold mb-2">Nexura Install</h1>
        <p class="text-slate-400 text-sm mb-6">Database + Admin user setup</p>

        <div class="mb-6 p-4 rounded-xl text-sm text-left space-y-2 border <?php echo ($mysqlOk && $dbOk) ? 'bg-emerald-500/10 border-emerald-500/30' : 'bg-amber-500/10 border-amber-500/30'; ?>">
            <p class="<?php echo $mysqlOk ? 'text-emerald-300' : 'text-red-300'; ?>">
                <?php echo $mysqlOk ? '✓ MySQL running' : '✗ MySQL OFF — XAMPP se Start karein'; ?>
            </p>
            <p class="<?php echo $dbOk ? 'text-emerald-300' : 'text-amber-300'; ?>">
                <?php echo $dbOk ? "✓ Database nexura_db connected ($userCount users)" : '○ Database abhi install nahi — neeche Install click karein'; ?>
            </p>
        </div>

        <?php if ($message): ?>
            <div class="mb-6 p-4 rounded-xl text-sm <?php echo $success ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30' : 'bg-red-500/10 text-red-300 border border-red-500/30'; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>

        <?php if ($dbOk && !$message): ?>
            <div class="mb-6 p-4 rounded-xl text-sm bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                Sab theek hai — website chal sakti hai!
            </div>
        <?php endif; ?>

        <form method="post">
            <button type="submit" <?php echo $mysqlOk ? '' : 'disabled'; ?>
                class="w-full py-3 rounded-xl font-semibold mb-4 <?php echo $mysqlOk ? 'bg-gradient-to-r from-violet-600 to-emerald-500' : 'bg-slate-700 text-slate-400 cursor-not-allowed'; ?>">
                <?php echo $dbOk ? 'Re-install / Repair Database' : 'Install Database Now'; ?>
            </button>
        </form>

        <div class="text-left text-sm text-slate-400 space-y-2">
            <p>1. XAMPP → Apache + MySQL <strong class="text-white">ON</strong></p>
            <p>2. MySQL green ho → Install click</p>
            <p>3. Admin: <code class="text-violet-300">admin</code> / <code class="text-emerald-300">admin123</code></p>
        </div>

        <div class="mt-6 flex flex-col gap-2 text-sm">
            <a href="../project/app.html" class="text-emerald-400 hover:underline">→ Mobile App</a>
            <a href="../project/index.html" class="text-violet-400 hover:underline">→ Website</a>
            <a href="admin/login.php" class="text-violet-400 hover:underline">→ Admin Login</a>
            <a href="confirm.php" class="text-slate-400 hover:underline">→ Backend Confirm (14 tests)</a>
            <a href="api/health.php" class="text-slate-400 hover:underline">→ API Health Check</a>
        </div>
    </div>
</body>
</html>
